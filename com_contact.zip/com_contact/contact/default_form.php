<?php
/**
 * @package     Joomla.Site
 * @subpackage  com_contact
 *
 * @copyright   Copyright (C) 2005 - 2019 Open Source Matters, Inc. All rights reserved.
 * @license     GNU General Public License version 2 or later; see LICENSE.txt
 */

defined('_JEXEC') or die;

JHtml::_('behavior.keepalive');
JHtml::_('behavior.formvalidator');

$dsgvotext = "Ich habe die <a href=\"javascript:void(0)\" rel=\"nofollow\" onclick=\"DD_PushUpContent('<p>Die Datenschutzerklärung können Sie über den nachfolgenden Button in neuem Browser Tab zum lesen öffnen.</p><p><a class=\'btn\' target=\'_blank\' href=\'/datenschutz\'>Datenschutzerklärung anzeigen</a></p>','Datenschutzerklärung anzeigen')\">Datenschutzerklärung</a> zur Kenntnis genommen. Ich stimme zu, dass meine Angaben und Daten zur Beantwortung meiner Anfrage elektronisch erhoben und gespeichert werden. Hinweis: Sie können Ihre Einwilligung jederzeit schriftlich oder per E-Mail unter der im <a href=\"javascript:void(0)\" rel=\"nofollow\" onclick=\"DD_PushUpContent('<p>Das Impressum können Sie über den nachfolgenden Button in neuem Browser Tab zum lesen öffnen.</p><p><a class=\'btn\' target=\'_blank\' href=\'/impressum\'>Impressum anzeigen</a></p>','Impressum anzeigen')\">Impressum</a> genannten Adresse widerrufen.";

$formElements = [];

array_push($formElements, $this->form->getFieldsets()['fields-1']);
$formElements = array_merge($formElements, $this->form->getFieldsets());
array_pop($formElements);

?>
<style>
    #jform_com_fields_dsgvo {
        border: 0;
        margin: 20px 0;
        padding: 0;
    }
</style>
<div class="contact-form">
	<form id="contact-form" action="<?php echo JRoute::_('index.php'); ?>" method="post" class="form-validate form-horizontal well">
		<?php foreach ($formElements as $fieldset) : ?>
			<?php if ($fieldset->name === 'captcha' && !$this->captchaEnabled) : ?>
				<?php continue; ?>
			<?php endif; ?>
			<?php $fields = $this->form->getFieldset($fieldset->name); ?>
			<?php if (count($fields)) : ?>

					<?php if (isset($fieldset->label) && ($legend = trim(JText::_($fieldset->label))) !== '') : ?>
					<?php endif; ?>
					<?php foreach ($fields as $field) : ?>

                        <?php if($field->name == 'jform[com_fields][telefon]'): ?>
                            <?php $telefon = $field->renderField(); ?>
                       <?php endif; ?>

                        <?php if($field->name != 'jform[com_fields][telefon]' &&
                                $field->name != 'jform[com_fields][dsgvo][]'): ?>
                            <?php echo $field->renderField(); ?>
                        <?php endif; ?>


                        <?php if($field->name == 'jform[com_fields][dsgvo][]'): ?>
                            <?php $dsgvo = $field->renderField(); ?>
                        <?php endif; ?>


                        <?php if($field->name == 'jform[contact_name]'): ?>
                            <?php echo $telefon; ?>
                        <?php endif; ?>

                        <?php if($field->name == 'jform[contact_message]'): ?>
                            <?php echo str_replace('dsgvotext',$dsgvotext, $dsgvo); ?>
                        <?php endif; ?>

					<?php endforeach; ?>
			<?php endif; ?>
		<?php endforeach; ?>
		<div class="control-group">
			<div class="controls">
				<button class="btn btn-primary validate" type="submit"><?php echo JText::_('COM_CONTACT_CONTACT_SEND'); ?></button>
				<input type="hidden" name="option" value="com_contact" />
				<input type="hidden" name="task" value="contact.submit" />
				<input type="hidden" name="return" value="<?php echo $this->return_page; ?>" />
				<input type="hidden" name="id" value="<?php echo $this->contact->slug; ?>" />
				<?php echo JHtml::_('form.token'); ?>
			</div>
		</div>
	</form>
</div>
